"""Cloud storage bucket probing — S3, GCS, Azure."""

from __future__ import annotations

import json
import logging
import subprocess
from pathlib import Path

import requests

from recon.context import ReconContext
from recon.utils import phase_banner, tool_path, write_lines

LOG = logging.getLogger("recon.phase_cloud")

# Bucket name candidates from target domain
def _bucket_names(target: str) -> list[str]:
    base = target.split(".")[0]
    parts = target.replace(".", "-").split("-")
    names = {
        target.replace(".", "-"),
        target.replace(".", ""),
        base,
        f"{base}-backup",
        f"{base}-dev",
        f"{base}-staging",
        f"{base}-prod",
        f"{base}-assets",
        f"{base}-media",
        f"{base}-static",
        f"{base}-uploads",
        f"{base}-data",
    }
    if len(parts) > 1:
        names.add("-".join(parts))
    return sorted(names)


def _probe_s3(name: str, ctx: ReconContext) -> dict | None:
    url = f"https://{name}.s3.amazonaws.com/"
    try:
        ctx.rate_limiter.wait()
        resp = requests.get(url, timeout=10, allow_redirects=True)
        if resp.status_code in (200, 403):
            listable = "ListBucketResult" in resp.text or "<Contents>" in resp.text
            return {
                "provider": "aws_s3",
                "bucket": name,
                "url": url,
                "status": resp.status_code,
                "listable": listable,
                "snippet": resp.text[:300],
            }
    except requests.RequestException:
        pass
    return None


def _probe_gcs(name: str, ctx: ReconContext) -> dict | None:
    url = f"https://storage.googleapis.com/{name}/"
    try:
        ctx.rate_limiter.wait()
        resp = requests.get(url, timeout=10)
        if resp.status_code in (200, 403):
            listable = "ListBucketResult" in resp.text or "<Contents>" in resp.text
            return {
                "provider": "gcs",
                "bucket": name,
                "url": url,
                "status": resp.status_code,
                "listable": listable,
                "snippet": resp.text[:300],
            }
    except requests.RequestException:
        pass
    return None


def _probe_azure(name: str, ctx: ReconContext) -> dict | None:
    url = f"https://{name}.blob.core.windows.net/?restype=container&comp=list"
    try:
        ctx.rate_limiter.wait()
        resp = requests.get(url, timeout=10)
        if resp.status_code in (200, 403):
            return {
                "provider": "azure_blob",
                "bucket": name,
                "url": url,
                "status": resp.status_code,
                "listable": "EnumerationResults" in resp.text,
                "snippet": resp.text[:300],
            }
    except requests.RequestException:
        pass
    return None


def _s3scanner_probe(ctx: ReconContext, names: list[str]) -> list[dict]:
    scanner = tool_path("s3scanner", ctx.config)
    if not scanner or not names:
        return []

    bucket_file = ctx.phase1 / "s3_bucket_candidates.txt"
    write_lines(bucket_file, names)
    out_json = ctx.phase1 / "s3scanner.jsonl"
    try:
        result = subprocess.run(
            [scanner, "scan", "-bucket-file", str(bucket_file), "-json"],
            capture_output=True,
            text=True,
            timeout=600,
            check=False,
        )
        findings: list[dict] = []
        for line in (result.stdout or "").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                findings.append(
                    {
                        "provider": "aws_s3",
                        "bucket": data.get("bucket") or data.get("name", ""),
                        "url": data.get("url") or f"https://{data.get('bucket', '')}.s3.amazonaws.com/",
                        "status": data.get("status") or data.get("status_code"),
                        "listable": data.get("listable", False),
                        "snippet": str(data)[:300],
                        "source": "s3scanner",
                    }
                )
            except json.JSONDecodeError:
                continue
        if findings:
            out_json.write_text(
                "\n".join(json.dumps(f) for f in findings) + "\n",
                encoding="utf-8",
            )
        return findings
    except (subprocess.SubprocessError, OSError) as exc:
        LOG.warning("s3scanner failed: %s", exc)
        return []


def run(ctx: ReconContext) -> None:
    phase_banner("Cloud Bucket Probing", 1)
    out_jsonl = ctx.phase1 / "cloud_buckets.jsonl"
    out_txt = ctx.phase1 / "cloud_buckets.txt"

    findings: list[dict] = []
    names = _bucket_names(ctx.target)
    for name in names:
        for probe in (_probe_s3, _probe_gcs, _probe_azure):
            result = probe(name, ctx)
            if result:
                findings.append(result)
                LOG.info(
                    "Cloud bucket: %s %s status=%s listable=%s",
                    result["provider"],
                    name,
                    result["status"],
                    result.get("listable"),
                )

    scanner_hits = _s3scanner_probe(ctx, names)
    seen = {f.get("bucket") for f in findings}
    for hit in scanner_hits:
        if hit.get("bucket") not in seen:
            findings.append(hit)
            seen.add(hit.get("bucket"))

    out_jsonl.write_text(
        "\n".join(json.dumps(f) for f in findings) + ("\n" if findings else ""),
        encoding="utf-8",
    )
    write_lines(
        out_txt,
        [f"{f['provider']}: {f['url']} status={f['status']} listable={f['listable']}" for f in findings],
    )
    LOG.info("Cloud bucket probe complete: %d hits", len(findings))
