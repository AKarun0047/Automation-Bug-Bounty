#!/usr/bin/env bash
# Install tools required by recon-all.sh
set -euo pipefail

PDTM_BIN="${HOME}/.pdtm/go/bin"
GO_BIN="$(go env GOPATH)/bin"
export PATH="${PATH}:${GO_BIN}:${PDTM_BIN}:${HOME}/.local/bin}"

mkdir -p "$PDTM_BIN"

echo "==> ProjectDiscovery tools (pdtm)..."
if ! command -v pdtm &>/dev/null; then
  go install -v github.com/projectdiscovery/pdtm/cmd/pdtm@latest
fi
pdtm -install subfinder httpx nuclei naabu katana uncover 2>/dev/null || pdtm -install-all

echo "==> Go tools..."
go install github.com/tomnomnom/assetfinder@latest
go install github.com/tomnomnom/waybackurls@latest
go install github.com/bp0lr/gauplus@latest
go install github.com/PentestPad/subzy@latest
go install github.com/owasp-amass/amass/v4/...@master

echo "==> Python tools (pipx or pip)..."
install_py() {
  if command -v pipx &>/dev/null; then
    pipx install "$1" 2>/dev/null || pipx upgrade "$1" 2>/dev/null || true
  else
    pip3 install --user "$1" 2>/dev/null || true
  fi
}
install_py waymore

echo "==> System packages (optional)..."
if command -v apt &>/dev/null; then
  sudo apt install -y nmap 2>/dev/null || true
fi

echo ""
echo "Done. Add to ~/.bashrc:"
echo "  export PATH=\"\${PATH}:${PDTM_BIN}:${GO_BIN}:\${HOME}/.local/bin\""
echo ""
echo "Run: ./recon-all.sh target.com"
