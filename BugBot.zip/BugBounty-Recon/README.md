# BugBounty-Recon

Single-script bug bounty reconnaissance. One file, flat outputs, rate-limited, 24/7 ready.

## Quick start (Kali / Linux)

```bash
# 1. Install tools (once)
chmod +x install.sh recon-all.sh
./install.sh

# 2. API keys (optional)
cp .env.example .env
nano .env

# 3. Add targets
nano targets.txt

# 4. Run
set -a && source .env && set +a
export PATH="${PATH}:$(go env GOPATH)/bin:${HOME}/.pdtm/go/bin:${HOME}/.local/bin"

./recon-all.sh justeattakeaway.com
```

## Output

Each target → `output/<domain>/`:

```
output/justeattakeaway.com/
├── subdomains.txt
├── live_hosts.txt
├── urls.txt
├── sensitive_urls.txt
├── open_ports.txt
├── nmap_results.txt
├── nuclei_results.txt
├── takeover_candidates.txt
├── secrets.txt
├── httpx_full.txt
└── REPORT_justeattakeaway.com.txt
```

## Commands

```bash
./recon-all.sh target.com              # one target
./recon-all.sh -f targets.txt          # multiple targets
./recon-all.sh --daemon -f targets.txt # 24/7 loop (every 6h)
./recon-all.sh --resume --daemon -f targets.txt  # skip fresh scans
```

## Rate limiting

```bash
export RATE_LIMIT=80
export THREADS=30
export SLEEP_BETWEEN_TOOLS=3
export LOOP_HOURS=6
./recon-all.sh --daemon -f targets.txt
```

## 24/7 with tmux

```bash
tmux new -s recon
cd ~/BugBounty-Recon
set -a && source .env && set +a
export PATH="${PATH}:$(go env GOPATH)/bin:${HOME}/.pdtm/go/bin:${HOME}/.local/bin"
./recon-all.sh --daemon -f targets.txt
# Ctrl+B D to detach
```

## Manual testing order

1. `REPORT_<domain>.txt` — start here
2. `takeover_candidates.txt`
3. `nuclei_results.txt` — confirm each hit
4. `sensitive_urls.txt` → import to Burp
5. `live_hosts.txt` — auth/admin/staging
6. `urls.txt` — full fuzz
7. `nmap_results.txt` — unusual services

## Add new target

```bash
echo "newtarget.com" >> targets.txt
# daemon picks it up on next cycle
```
