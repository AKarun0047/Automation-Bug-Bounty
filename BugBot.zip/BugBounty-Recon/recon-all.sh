#!/usr/bin/env bash
# recon-all.sh — Single-file bug bounty recon (24/7 capable)
# Usage:
#   ./recon-all.sh target.com              # one target
#   ./recon-all.sh -f targets.txt          # list of targets
#   ./recon-all.sh --daemon -f targets.txt # loop forever (24/7)
#   ./recon-all.sh --resume target.com     # skip if output fresh today
#
# Output per target → ./output/<domain>/
#   subdomains.txt, live_hosts.txt, urls.txt, sensitive_urls.txt,
#   open_ports.txt, nmap_results.txt, nuclei_results.txt,
#   takeover_candidates.txt, secrets.txt, REPORT_<domain>.txt

set -uo pipefail

###############################################################################
# CONFIG — edit these or export before running
###############################################################################
OUTPUT_BASE="${OUTPUT_BASE:-./output}"
TARGETS_FILE="${TARGETS_FILE:-targets.txt}"
LOOP_HOURS="${LOOP_HOURS:-6}"              # hours between full cycles (daemon mode)
RATE_LIMIT="${RATE_LIMIT:-80}"             # max HTTP probes/sec (httpx/nuclei)
THREADS="${THREADS:-30}"                   # parallel workers (keep low)
SLEEP_BETWEEN_TOOLS="${SLEEP_BETWEEN_TOOLS:-3}"  # seconds between heavy tools
SLEEP_BETWEEN_TARGETS="${SLEEP_BETWEEN_TARGETS:-60}"
MAX_SUBS_PROBE="${MAX_SUBS_PROBE:-5000}"   # cap subs sent to httpx/nuclei
TOOLS_PATH="${TOOLS_PATH:-${HOME}/.pdtm/go/bin:${HOME}/go/bin:${HOME}/.local/bin}"
DAEMON=0
RESUME=0
TARGETS=()

###############################################################################
# SETUP
###############################################################################
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
export PATH="${PATH}:${TOOLS_PATH}"
# shellcheck disable=SC1091
[ -f .env ] && set -a && source .env && set +a

log()  { echo "[$(date '+%H:%M:%S')] $*"; }
warn() { echo "[$(date '+%H:%M:%S')] WARN: $*" >&2; }
die()  { echo "[$(date '+%H:%M:%S')] ERROR: $*" >&2; exit 1; }

have() { command -v "$1" &>/dev/null; }

rate_sleep() { sleep "${SLEEP_BETWEEN_TOOLS}"; }

dedupe_file() {
  local f="$1"
  [ -f "$f" ] || return 0
  sort -u "$f" -o "$f"
}

count_lines() {
  [ -f "$1" ] && wc -l <"$1" | tr -d ' ' || echo 0
}

cap_lines() {
  local src="$1" dest="$2" max="$3"
  head -n "$max" "$src" >"$dest"
}

parse_args() {
  while [ $# -gt 0 ]; do
    case "$1" in
      --daemon|-d)     DAEMON=1; shift ;;
      --resume|-r)     RESUME=1; shift ;;
      -f|--file)       TARGETS_FILE="$2"; shift 2 ;;
      -o|--output)     OUTPUT_BASE="$2"; shift 2 ;;
      --rate)          RATE_LIMIT="$2"; shift 2 ;;
      --loop-hours)    LOOP_HOURS="$2"; shift 2 ;;
      -h|--help)
        sed -n '2,12p' "$0"
        exit 0
        ;;
      -*) die "Unknown option: $1" ;;
      *)  TARGETS+=("$1"); shift ;;
    esac
  done
  if [ ${#TARGETS[@]} -eq 0 ] && [ -f "$TARGETS_FILE" ]; then
    while IFS= read -r line || [ -n "$line" ]; do
      line="${line%%#*}"
      line="$(echo "$line" | xargs)"
      [ -n "$line" ] && TARGETS+=("$line")
    done <"$TARGETS_FILE"
  fi
  [ ${#TARGETS[@]} -gt 0 ] || die "No targets. Pass domain or use -f targets.txt"
}

should_skip() {
  local dir="$1"
  [ "$RESUME" -eq 0 ] && return 1
  local report="$dir/REPORT_$(basename "$dir").txt"
  [ -f "$report" ] || return 1
  local mtime age
  mtime="$(stat -c %Y "$report" 2>/dev/null || stat -f %m "$report" 2>/dev/null || echo 0)"
  age=$(( $(date +%s) - mtime ))
  [ "$age" -lt 86400 ]
}

phase_subdomains() {
  local target="$1" dir="$2"
  local subs="$dir/subdomains.txt"
  local tmp="$dir/.tmp"
  mkdir -p "$tmp"
  : >"$subs"

  log "[$target] Phase 1: subdomain discovery"

  if have subfinder; then
    subfinder -d "$target" -all -silent -o "$tmp/subfinder.txt" 2>/dev/null || true
    cat "$tmp/subfinder.txt" >>"$subs"
    rate_sleep
  else
    warn "subfinder not found — run ./install.sh"
  fi

  if have assetfinder; then
    assetfinder --subs-only "$target" >>"$subs" 2>/dev/null || true
    rate_sleep
  fi

  if have amass; then
    timeout 600 amass enum -passive -d "$target" -o "$tmp/amass.txt" 2>/dev/null || true
    cat "$tmp/amass.txt" >>"$subs"
    rate_sleep
  fi

  if have curl; then
    curl -fsSL "https://crt.sh/?q=%25.${target}&output=json" 2>/dev/null \
      | grep -oP '"name_value"\s*:\s*"\K[^"]+' 2>/dev/null \
      | tr ',' '\n' | sed 's/^\*\.//' >>"$subs" || true
    rate_sleep
  fi

  curl -fsSL "https://api.hackertarget.com/hostsearch/?q=${target}" 2>/dev/null \
    | cut -d, -f1 >>"$subs" || true
  rate_sleep

  echo "$target" >>"$subs"
  echo "www.${target}" >>"$subs"

  {
    grep -iF ".${target}" "$subs" 2>/dev/null || true
    grep -iFx "${target}" "$subs" 2>/dev/null || true
  } | tr '[:upper:]' '[:lower:]' | sort -u >"$tmp/filtered.txt" || true
  mv "$tmp/filtered.txt" "$subs"
  dedupe_file "$subs"
  log "[$target] Subdomains: $(count_lines "$subs")"
}

phase_live_and_ports() {
  local target="$1" dir="$2"
  local subs="$dir/subdomains.txt"
  local live="$dir/live_hosts.txt"
  local ports="$dir/open_ports.txt"
  local nmap_out="$dir/nmap_results.txt"
  local probe="$dir/.probe_urls.txt"
  local capped="$dir/.subs_capped.txt"
  local tmp="$dir/.tmp"

  log "[$target] Phase 2: live hosts + ports"
  : >"$live"
  : >"$ports"
  : >"$nmap_out"

  cap_lines "$subs" "$capped" "$MAX_SUBS_PROBE"

  if have naabu; then
    naabu -list "$capped" -rate "$RATE_LIMIT" -silent -o "$tmp/naabu.txt" 2>/dev/null || true
    [ -f "$tmp/naabu.txt" ] && cp "$tmp/naabu.txt" "$ports"
    rate_sleep
  fi

  : >"$probe"
  if [ -s "$ports" ]; then
    while IFS= read -r line; do
      host="${line%%:*}"
      port="${line##*:}"
      if [ "$port" = "443" ]; then
        echo "https://${host}" >>"$probe"
      elif [ "$port" = "80" ]; then
        echo "http://${host}" >>"$probe"
      else
        echo "http://${host}:${port}" >>"$probe"
      fi
    done <"$ports"
  fi
  while IFS= read -r sub; do
    echo "https://${sub}" >>"$probe"
    echo "http://${sub}" >>"$probe"
  done <"$capped"
  dedupe_file "$probe"

  if have httpx; then
    httpx -l "$probe" -silent -status-code -title -tech-detect \
      -rate-limit "$RATE_LIMIT" -threads "$THREADS" \
      -o "$tmp/httpx.txt" 2>/dev/null || true
    if [ -s "$tmp/httpx.txt" ]; then
      awk '{print $1}' "$tmp/httpx.txt" | sort -u >"$live"
      cp "$tmp/httpx.txt" "$dir/httpx_full.txt"
    fi
    rate_sleep
  else
    warn "httpx not found"
    cp "$probe" "$live"
  fi

  dedupe_file "$live"
  log "[$target] Live hosts: $(count_lines "$live")"

  if have nmap && [ -s "$live" ]; then
    head -n 30 "$live" | sed -E 's|https?://||; s|/.*||; s|:.*||' | sort -u >"$tmp/nmap_hosts.txt"
    log "[$target] nmap service scan (top 30 hosts)..."
    while IFS= read -r host; do
      nmap -sV -T3 --max-rate "$RATE_LIMIT" -Pn -p 80,443,8080,8443,3000,8000,22,3306 \
        "$host" >>"$nmap_out" 2>/dev/null || true
      sleep 2
    done <"$tmp/nmap_hosts.txt"
    rate_sleep
  elif [ -s "$ports" ]; then
    {
      echo "# naabu port scan (nmap not run or unavailable)"
      cat "$ports"
    } >"$nmap_out"
  fi
}

phase_urls() {
  local target="$1" dir="$2"
  local urls="$dir/urls.txt"
  local sensitive="$dir/sensitive_urls.txt"
  local tmp="$dir/.tmp"

  log "[$target] Phase 3: URL harvest"
  : >"$urls"

  if have gauplus; then
    gauplus --threads 5 --subs "$target" --blacklist ttf,woff,woff2,svg,png,jpg,gif,ico,css \
      2>/dev/null >>"$urls" || true
    rate_sleep
  elif have gau; then
    gau --subs "$target" 2>/dev/null >>"$urls" || true
    rate_sleep
  fi

  if have waybackurls; then
    waybackurls "$target" 2>/dev/null >>"$urls" || true
    rate_sleep
  fi

  if have waymore; then
    waymore -i "$target" -mode U -oU "$tmp/waymore.txt" 2>/dev/null || true
    [ -f "$tmp/waymore.txt" ] && cat "$tmp/waymore.txt" >>"$urls"
    rate_sleep
  fi

  if have katana && [ -s "$dir/live_hosts.txt" ]; then
    head -n 20 "$dir/live_hosts.txt" >"$tmp/katana_seeds.txt"
    katana -list "$tmp/katana_seeds.txt" -d 3 -c 10 -silent 2>/dev/null >>"$urls" || true
    rate_sleep
  fi

  dedupe_file "$urls"
  grep -iE '^https?://' "$urls" >"$tmp/http.txt" 2>/dev/null && mv "$tmp/http.txt" "$urls" || true

  grep -iE 'admin|api|token|logout|password|secret|dashboard|staging|internal|debug|metrics|\.env|\.git|redirect=|url=|next=' \
    "$urls" 2>/dev/null | sort -u >"$sensitive" || : >"$sensitive"

  log "[$target] URLs: $(count_lines "$urls") | Sensitive: $(count_lines "$sensitive")"
}

phase_takeover() {
  local target="$1" dir="$2"
  local subs="$dir/subdomains.txt"
  local out="$dir/takeover_candidates.txt"
  local tmp="$dir/.tmp"

  log "[$target] Phase 4: takeover checks"
  : >"$out"

  if have subzy && [ -s "$subs" ]; then
    cap_lines "$subs" "$tmp/subs_cap.txt" 1000
    subzy run --targets "$tmp/subs_cap.txt" --concurrency 20 --output "$tmp/subzy.txt" 2>/dev/null || true
    [ -f "$tmp/subzy.txt" ] && grep -i vulnerable "$tmp/subzy.txt" >>"$out" || true
    rate_sleep
  fi

  if have nuclei && [ -s "$subs" ]; then
    head -n 500 "$subs" | sed 's/^/https:\/\//' >"$tmp/subs_https.txt"
    nuclei -l "$tmp/subs_https.txt" -t takeovers/ -silent -rate-limit "$RATE_LIMIT" \
      -o "$tmp/nuclei_takeover.txt" 2>/dev/null || true
    [ -f "$tmp/nuclei_takeover.txt" ] && cat "$tmp/nuclei_takeover.txt" >>"$out"
    rate_sleep
  fi

  dedupe_file "$out"
  log "[$target] Takeover candidates: $(count_lines "$out")"
}

phase_nuclei() {
  local target="$1" dir="$2"
  local live="$dir/live_hosts.txt"
  local urls="$dir/urls.txt"
  local out="$dir/nuclei_results.txt"
  local tmp="$dir/.tmp"

  log "[$target] Phase 5: nuclei vulnerability scan"
  : >"$out"

  if ! have nuclei; then
    warn "nuclei not found — skipping"
    return
  fi

  {
    head -n 200 "$live" 2>/dev/null
    head -n 300 "$urls" 2>/dev/null
  } | sort -u >"$tmp/nuclei_targets.txt"

  [ ! -s "$tmp/nuclei_targets.txt" ] && return

  nuclei -l "$tmp/nuclei_targets.txt" \
    -severity critical,high,medium \
    -rate-limit "$RATE_LIMIT" -bulk-size 25 -c 25 \
    -t cves/,exposures/,misconfigurations/,technologies/,default-logins/ \
    -silent -o "$out" 2>/dev/null || true

  rate_sleep
  log "[$target] Nuclei findings: $(count_lines "$out")"
}

phase_secrets() {
  local target="$1" dir="$2"
  local urls="$dir/urls.txt"
  local out="$dir/secrets.txt"
  local tmp="$dir/.tmp"

  log "[$target] Phase 6: secret scan (JS URLs)"
  : >"$out"

  if ! have nuclei || [ ! -s "$urls" ]; then
    return
  fi

  grep -iE '\.js($|\?)' "$urls" 2>/dev/null | head -n 100 >"$tmp/js.txt" || true
  [ ! -s "$tmp/js.txt" ] && return

  nuclei -l "$tmp/js.txt" -t exposures/tokens/,exposures/apis/ \
    -silent -rate-limit "$RATE_LIMIT" -o "$tmp/nuclei_secrets.txt" 2>/dev/null || true
  [ -f "$tmp/nuclei_secrets.txt" ] && cp "$tmp/nuclei_secrets.txt" "$out"
  rate_sleep
  log "[$target] Secret hits: $(count_lines "$out")"
}

write_report() {
  local target="$1" dir="$2"
  local report="$dir/REPORT_${target}.txt"
  local now
  now="$(date '+%Y-%m-%d %H:%M UTC')"

  log "[$target] Writing report → $report"

  {
    echo "================================================================"
    echo "  RECON REPORT: ${target}"
    echo "  Generated: ${now}"
    echo "  Rate limit: ${RATE_LIMIT}/s | Threads: ${THREADS}"
    echo "================================================================"
    echo ""
    echo "=== SUMMARY ==="
    echo "Subdomains:    $(count_lines "$dir/subdomains.txt")"
    echo "Live hosts:    $(count_lines "$dir/live_hosts.txt")"
    echo "URLs:          $(count_lines "$dir/urls.txt")"
    echo "Sensitive URLs:$(count_lines "$dir/sensitive_urls.txt")"
    echo "Open ports:    $(count_lines "$dir/open_ports.txt")"
    echo "Takeovers:     $(count_lines "$dir/takeover_candidates.txt")"
    echo "Nuclei hits:   $(count_lines "$dir/nuclei_results.txt")"
    echo "Secrets:       $(count_lines "$dir/secrets.txt")"
    echo ""

    if [ -s "$dir/takeover_candidates.txt" ]; then
      echo "=== TAKEOVER CANDIDATES (test first) ==="
      head -n 30 "$dir/takeover_candidates.txt"
      echo ""
    fi

    if [ -s "$dir/nuclei_results.txt" ]; then
      echo "=== NUCLEI — CRITICAL/HIGH (verify manually) ==="
      grep -iE '\[(critical|high)\]' "$dir/nuclei_results.txt" | head -n 40 || head -n 40 "$dir/nuclei_results.txt"
      echo ""
    fi

    if [ -s "$dir/sensitive_urls.txt" ]; then
      echo "=== SENSITIVE URLs (import to Burp) ==="
      head -n 50 "$dir/sensitive_urls.txt"
      echo ""
    fi

    if [ -s "$dir/live_hosts.txt" ]; then
      echo "=== LIVE HOSTS (top 40) ==="
      head -n 40 "$dir/live_hosts.txt"
      echo ""
    fi

    if [ -s "$dir/open_ports.txt" ]; then
      echo "=== OPEN PORTS (sample) ==="
      head -n 40 "$dir/open_ports.txt"
      echo ""
    fi

    if [ -s "$dir/nmap_results.txt" ]; then
      echo "=== NMAP / SERVICE SCAN ==="
      head -n 80 "$dir/nmap_results.txt"
      echo ""
    fi

    if [ -s "$dir/secrets.txt" ]; then
      echo "=== SECRETS (validate before report) ==="
      head -n 20 "$dir/secrets.txt"
      echo ""
    fi

    echo "=== MANUAL TESTING ORDER ==="
    echo "  1. takeover_candidates.txt"
    echo "  2. nuclei_results.txt (confirm each)"
    echo "  3. sensitive_urls.txt → Burp"
    echo "  4. live_hosts.txt → auth/admin/staging"
    echo "  5. urls.txt full fuzz"
    echo "  6. nmap_results.txt non-standard services"
    echo ""
    echo "================================================================"
  } >"$report"
}

run_target() {
  local target="$1"
  target="$(echo "$target" | tr '[:upper:]' '[:lower:]' | xargs)"
  [ -n "$target" ] || return 0

  local dir="${OUTPUT_BASE}/${target}"
  mkdir -p "$dir/.tmp"

  if should_skip "$dir"; then
    log "[$target] Skipping — report fresh (<24h). Run without --resume to force."
    return 0
  fi

  log "========== START: $target → $dir =========="
  local start
  start=$(date +%s)

  phase_subdomains "$target" "$dir"
  phase_live_and_ports "$target" "$dir"
  phase_urls "$target" "$dir"
  phase_takeover "$target" "$dir"
  phase_nuclei "$target" "$dir"
  phase_secrets "$target" "$dir"
  write_report "$target" "$dir"

  local elapsed=$(( $(date +%s) - start ))
  log "========== DONE: $target (${elapsed}s) → $dir/REPORT_${target}.txt =========="
  rm -rf "$dir/.tmp" 2>/dev/null || true
}

run_cycle() {
  log "=== Cycle start: ${#TARGETS[@]} target(s) ==="
  for t in "${TARGETS[@]}"; do
    run_target "$t"
    sleep "$SLEEP_BETWEEN_TARGETS"
  done
  log "=== Cycle complete ==="
}

parse_args "$@"
mkdir -p "$OUTPUT_BASE"

if [ "$DAEMON" -eq 1 ]; then
  log "Daemon mode — loop every ${LOOP_HOURS}h (Ctrl+C to stop)"
  log "Targets: ${TARGETS[*]}"
  log "Output:  ${OUTPUT_BASE}/"
  while true; do
    run_cycle
    log "Sleeping ${LOOP_HOURS} hours..."
    sleep "$(( LOOP_HOURS * 3600 ))"
  done
else
  run_cycle
fi
