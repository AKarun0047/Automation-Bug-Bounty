#!/usr/bin/env bash
# Install all external recon tools for Automation-Bug-Bounty (see recon-automation-spec.md)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
VENV_DIR="${PROJECT_ROOT}/.venv"
BUGBOUNTY_DIR="${PROJECT_ROOT}/bugbounty"
WORDLISTS_DIR="${BUGBOUNTY_DIR}/wordlists"
GO_BIN="$(go env GOPATH)/bin"
PDTM_BIN="${HOME}/.pdtm/go/bin"
SECLISTS_BASE="https://raw.githubusercontent.com/danielmiessler/SecLists/master"

mkdir -p "$PDTM_BIN" "$WORDLISTS_DIR" "$BUGBOUNTY_DIR"
export PATH="${PATH}:${GO_BIN}:${PDTM_BIN}:${HOME}/.local/bin:${VENV_DIR}/bin"

symlink_to_pdtm() {
  local tool="$1"
  if command -v "$tool" &>/dev/null && [ ! -e "$PDTM_BIN/$tool" ]; then
    ln -sf "$(command -v "$tool")" "$PDTM_BIN/$tool"
  fi
}

install_trufflehog() {
  if command -v trufflehog &>/dev/null; then
    symlink_to_pdtm trufflehog
    return
  fi
  curl -sSfL https://raw.githubusercontent.com/trufflesecurity/trufflehog/main/scripts/install.sh \
    | sh -s -- -b "$PDTM_BIN"
}

install_massdns() {
  if command -v massdns &>/dev/null; then
    symlink_to_pdtm massdns
    return
  fi
  echo "==> Building massdns (required by puredns)..."
  local build_dir
  build_dir="$(mktemp -d)"
  git clone --depth 1 https://github.com/blechschmidt/massdns.git "${build_dir}/massdns"
  make -C "${build_dir}/massdns"
  install "${build_dir}/massdns/bin/massdns" "${PDTM_BIN}/massdns"
  rm -rf "${build_dir}"
}

ensure_venv() {
  if [ -d "$VENV_DIR" ]; then
    return
  fi
  if ! python3 -m venv "$VENV_DIR" 2>/dev/null; then
    echo "ERROR: Could not create venv. On Kali/Debian run:"
    echo "  sudo apt install python3-venv pipx"
    exit 1
  fi
  "${VENV_DIR}/bin/pip" install --upgrade pip
}

install_python_cli() {
  local pkg="$1"
  if command -v pipx &>/dev/null; then
    pipx install "$pkg" 2>/dev/null || pipx upgrade "$pkg"
  else
    ensure_venv
    "${VENV_DIR}/bin/pip" install "$pkg"
  fi
}

install_python_tools() {
  if command -v pipx &>/dev/null; then
    echo "==> Installing Python tools via pipx..."
  else
    echo "==> pipx not found — installing Python tools into ${VENV_DIR}..."
    echo "    (Tip: sudo apt install pipx for isolated CLI installs on Kali)"
  fi
  for pkg in waymore arjun wafw00f uro; do
    install_python_cli "$pkg"
    symlink_to_pdtm "$pkg"
  done
  if command -v pipx &>/dev/null; then
    pipx install 'git+https://github.com/devanshbatham/ParamSpider.git' 2>/dev/null \
      || pipx upgrade paramspider 2>/dev/null \
      || true
  else
    ensure_venv
    "${VENV_DIR}/bin/pip" install 'git+https://github.com/devanshbatham/ParamSpider.git'
  fi
  symlink_to_pdtm paramspider
}

download_wordlist() {
  local url="$1"
  local dest="$2"
  if [ -f "$dest" ]; then
    echo "  skip (exists): $(basename "$dest")"
  else
    echo "  fetch: $(basename "$dest")"
    curl -fsSL "$url" -o "$dest"
  fi
}

link_project_assets() {
  local resolvers="${WORDLISTS_DIR}/resolvers.txt"
  if [ -f "$resolvers" ]; then
    ln -sf "$resolvers" "${BUGBOUNTY_DIR}/resolvers.txt"
    ln -sf "$resolvers" "${PROJECT_ROOT}/resolvers.txt"
  fi
  local subs="${WORDLISTS_DIR}/subdomains-top1m.txt"
  if [ -f "$subs" ]; then
    mkdir -p "${PROJECT_ROOT}/wordlists"
    ln -sf "$subs" "${PROJECT_ROOT}/wordlists/subdomains-top1m.txt"
  fi
}

download_wordlists() {
  echo "==> Downloading wordlists into ${WORDLISTS_DIR}..."
  download_wordlist \
    "https://raw.githubusercontent.com/trickest/resolvers/main/resolvers.txt" \
    "${WORDLISTS_DIR}/resolvers.txt"
  download_wordlist \
    "${SECLISTS_BASE}/Discovery/DNS/subdomains-top1million-110000.txt" \
    "${WORDLISTS_DIR}/subdomains-top1m.txt"
  download_wordlist \
    "${SECLISTS_BASE}/Discovery/DNS/bit-and-byte-subdomains-top100000.txt" \
    "${WORDLISTS_DIR}/vhost-subdomains-top100k.txt"
  download_wordlist \
    "${SECLISTS_BASE}/Discovery/DNS/namelist.txt" \
    "${WORDLISTS_DIR}/vhost-namelist.txt"
  download_wordlist \
    "${SECLISTS_BASE}/Discovery/Web-Content/raft-medium-files.txt" \
    "${WORDLISTS_DIR}/dirs-raft-medium.txt"
  download_wordlist \
    "${SECLISTS_BASE}/Discovery/Web-Content/common.txt" \
    "${WORDLISTS_DIR}/dirs-common.txt"
  download_wordlist \
    "${SECLISTS_BASE}/Discovery/Web-Content/burp-parameter-names.txt" \
    "${WORDLISTS_DIR}/params-burp.txt"
  link_project_assets
}

setup_amass_config() {
  local amass_cfg="${HOME}/.config/amass/config.yaml"
  if [ -f "$amass_cfg" ]; then
    return
  fi
  mkdir -p "$(dirname "$amass_cfg")"
  cat >"$amass_cfg" <<'EOF'
# Add API keys for passive sources (Shodan, Censys, SecurityTrails, etc.)
# Docs: https://github.com/owasp-amass/amass/blob/master/doc/user_guide.md
options:
  datasources: "./datasources.yaml"
EOF
  echo "  created template: ${amass_cfg} (add API keys for best results)"
}

setup_subfinder_config() {
  local subfinder_cfg="${HOME}/.config/subfinder/provider-config.yaml"
  if [ -f "$subfinder_cfg" ]; then
    return
  fi
  mkdir -p "$(dirname "$subfinder_cfg")"
  cat >"$subfinder_cfg" <<'EOF'
# Add API keys: https://docs.projectdiscovery.io/tools/subfinder/install#post-install-configuration
EOF
  echo "  created template: ${subfinder_cfg} (add API keys for best results)"
}

echo "==> Automation-Bug-Bounty tool install (project: ${PROJECT_ROOT})"

echo "==> Installing ProjectDiscovery tools via pdtm..."
if ! command -v pdtm &>/dev/null; then
  go install -v github.com/projectdiscovery/pdtm/cmd/pdtm@latest
fi
pdtm -install-all -install-path

echo "==> Installing additional Go tools..."
go install github.com/ffuf/ffuf/v2@latest
go install github.com/owasp-amass/amass/v4/...@master
go install github.com/tomnomnom/assetfinder@latest
go install github.com/tomnomnom/waybackurls@latest
go install github.com/hakluke/hakrawler@latest
go install github.com/d3mondev/puredns/v2@latest
go install github.com/bp0lr/gauplus@latest
go install github.com/lc/gau/v2/cmd/gau@latest
go install github.com/BishopFox/jsluice/cmd/jsluice@latest
install_trufflehog
go install github.com/PentestPad/subzy@latest
go install github.com/sensepost/gowitness@latest
go install github.com/tomnomnom/gf@latest
install_massdns

for tool in ffuf amass assetfinder waybackurls hakrawler puredns massdns gauplus gau \
            jsluice trufflehog subzy gowitness gf; do
  symlink_to_pdtm "$tool"
done

install_python_tools

echo "==> Setting up API config templates..."
setup_amass_config
setup_subfinder_config

echo "==> Setting up gf patterns..."
if [ ! -d "$HOME/.gf" ]; then
  git clone https://github.com/1ndianl33t/Gf-Patterns "$HOME/.gf/"
fi

download_wordlists

if [ -f "${PROJECT_ROOT}/requirements.txt" ]; then
  echo "==> Installing Python orchestrator deps..."
  ensure_venv
  "${VENV_DIR}/bin/pip" install -r "${PROJECT_ROOT}/requirements.txt"
fi

echo ""
echo "Done. Recon orchestrator paths:"
echo "  tools_path:     ${PDTM_BIN}"
echo "  resolvers:      ${BUGBOUNTY_DIR}/resolvers.txt"
echo "  wordlists:      ${WORDLISTS_DIR}/"
echo "  python venv:    ${VENV_DIR}/"
echo ""
echo "Run recon:"
echo "  cd ${PROJECT_ROOT}"
echo "  source .venv/bin/activate"
echo "  python -m recon --config recon.config.yaml -v"
