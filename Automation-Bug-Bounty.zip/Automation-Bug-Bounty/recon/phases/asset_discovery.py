"""Phase 1 — Asset Discovery."""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path

import requests

from recon.context import ReconContext
from recon.scope import filter_in_scope
from recon.utils import (
    ensure_dir,
    filter_target_subdomains,
    phase_banner,
    read_jsonl,
    read_lines,
    run_cmd,
    run_parallel,
    tool_path,
    write_lines,
)

LOG = logging.getLogger("recon.phase1")

TAKEOVER_CNAME_SIGS = (
    "github.io",
    "herokuapp.com",
    "vercel.app",
    "netlify.app",
    "azurewebsites.net",
    "cloudfront.net",
    "fastly.net",
    "pantheonsite.io",
    "ghost.io",
    "myshopify.com",
    "surge.sh",
    "bitbucket.io",
)


def _passive_subfinder(ctx: ReconContext, passive_dir: Path) -> Path:
    out = passive_dir / "subfinder.txt"
    binary = tool_path("subfinder", ctx.config)
    if not binary:
        LOG.warning("subfinder not found — skipping")
        return out
    run_cmd([binary, "-d", ctx.target, "-all", "-recursive", "-silent", "-o", str(out)])
    return out


def _passive_amass(ctx: ReconContext, passive_dir: Path) -> Path:
    out = passive_dir / "amass.txt"
    binary = tool_path("amass", ctx.config)
    if not binary:
        LOG.warning("amass not found — skipping")
        return out
    run_cmd([binary, "enum", "-passive", "-d", ctx.target, "-o", str(out)], timeout=600)
    return out


def _passive_assetfinder(ctx: ReconContext, passive_dir: Path, *, related: bool = False) -> Path:
    out = passive_dir / ("assetfinder_related.txt" if related else "assetfinder.txt")
    binary = tool_path("assetfinder", ctx.config)
    if not binary:
        LOG.warning("assetfinder not found — skipping")
        return out
    cmd = [binary, ctx.target] if related else [binary, "--subs-only", ctx.target]
    result = run_cmd(cmd, timeout=300)
    if result.stdout.strip():
        write_lines(out, result.stdout.splitlines())
    return out


def _passive_subdominator(ctx: ReconContext, passive_dir: Path) -> Path:
    out = passive_dir / "subdominator.txt"
    binary = tool_path("subdominator", ctx.config)
    if not binary:
        LOG.warning("subdominator not found — skipping (pip install subdominator)")
        return out
    run_cmd([binary, "-d", ctx.target, "-o", str(out)], timeout=600)
    return out


def _passive_bbot(ctx: ReconContext, passive_dir: Path) -> Path:
    out = passive_dir / "bbot.txt"
    binary = tool_path("bbot", ctx.config)
    if not binary:
        LOG.warning("bbot not found — skipping (pip install bbot)")
        return out
    bbot_dir = passive_dir / "bbot_out"
    run_cmd(
        [binary, "-t", ctx.target, "-f", "subdomain-enum", "-o", str(bbot_dir), "--silent"],
        timeout=1800,
    )
    hosts: set[str] = set()
    suffix = f".{ctx.target.lower()}"
    if bbot_dir.exists():
        for path in bbot_dir.rglob("*.txt"):
            try:
                for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
                    if "DNS_NAME" in line:
                        parts = line.split()
                        if len(parts) >= 2:
                            host = parts[1].lower().strip()
                            if host.endswith(suffix) or host == ctx.target.lower():
                                hosts.add(host)
            except OSError:
                continue
    write_lines(out, sorted(hosts))
    return out


def _passive_crtsh(ctx: ReconContext, passive_dir: Path) -> Path:
    out = passive_dir / "crtsh.txt"
    try:
        resp = requests.get(
            f"https://crt.sh/?q=%.{ctx.target}&output=json",
            timeout=60,
        )
        if resp.ok:
            names: set[str] = set()
            for entry in resp.json():
                for name in str(entry.get("name_value", "")).split("\n"):
                    name = name.strip().replace("*.", "")
                    if name:
                        names.add(name.lower())
            write_lines(out, sorted(names))
    except (requests.RequestException, json.JSONDecodeError) as exc:
        LOG.warning("crt.sh fetch failed: %s", exc)
    return out


def _passive_hackertarget(ctx: ReconContext, passive_dir: Path) -> Path:
    out = passive_dir / "hackertarget.txt"
    try:
        resp = requests.get(
            f"https://api.hackertarget.com/hostsearch/?q={ctx.target}",
            timeout=30,
        )
        if resp.ok:
            hosts = [line.split(",")[0].strip() for line in resp.text.splitlines() if line.strip()]
            write_lines(out, hosts)
    except requests.RequestException as exc:
        LOG.warning("hackertarget fetch failed: %s", exc)
    return out


def _passive_otx(ctx: ReconContext, passive_dir: Path) -> Path:
    out = passive_dir / "otx.txt"
    try:
        resp = requests.get(
            f"https://otx.alienvault.com/api/v1/indicators/domain/{ctx.target}/passive_dns",
            timeout=30,
        )
        if resp.ok:
            hosts = [
                str(e.get("hostname", "")).lower()
                for e in resp.json().get("passive_dns", [])
                if e.get("hostname")
            ]
            write_lines(out, hosts)
    except (requests.RequestException, json.JSONDecodeError, KeyError) as exc:
        LOG.warning("OTX fetch failed: %s", exc)
    return out


def _github_subdomain_mining(ctx: ReconContext, passive_dir: Path) -> Path:
    out = passive_dir / "github_subdomains.txt"
    hints = passive_dir / "github_search_hints.txt"
    dorks = [
        f'site:github.com "{ctx.target}" ext:env',
        f'site:github.com "staging.{ctx.target}"',
        f'site:github.com "internal.{ctx.target}"',
        f'site:github.com "{ctx.target}" api_key',
    ]
    write_lines(hints, [f"https://github.com/search?q={d.replace(' ', '+')}&type=code" for d in dorks])

    token = os.environ.get("GITHUB_TOKEN", "").strip()
    if not token:
        LOG.info("GITHUB_TOKEN not set — wrote manual GitHub dork hints to %s", hints.name)
        return out

    hosts: set[str] = set()
    domain_re = re.compile(rf"[a-zA-Z0-9._-]+\.{re.escape(ctx.target)}", re.IGNORECASE)
    for dork in dorks[:4]:
        ctx.rate_limiter.wait()
        try:
            resp = requests.get(
                "https://api.github.com/search/code",
                headers={"Authorization": f"token {token}", "Accept": "application/vnd.github+json"},
                params={"q": dork, "per_page": "30"},
                timeout=30,
            )
            if not resp.ok:
                continue
            for item in resp.json().get("items", []):
                for match in item.get("text_matches", []) or []:
                    for host in domain_re.findall(str(match.get("fragment", ""))):
                        hosts.add(host.lower())
        except (requests.RequestException, json.JSONDecodeError, KeyError) as exc:
            LOG.debug("GitHub search failed: %s", exc)
    write_lines(out, sorted(hosts))
    return out


def _collect_acquisition_domains(ctx: ReconContext, passive_dir: Path) -> Path:
    """Related domains from assetfinder (acquisitions / sister brands)."""
    out = ctx.phase1 / "acquisition_domains.txt"
    related_path = passive_dir / "assetfinder_related.txt"
    if not related_path.exists():
        return out

    roots = {r.lower() for r in (ctx.config.scope_roots or ctx.config.targets)}
    acquisitions: list[str] = []
    for line in read_lines(related_path):
        host = line.lower().strip()
        if not host or host in roots:
            continue
        if "." not in host:
            continue
        if not any(host == r or host.endswith(f".{r}") for r in roots):
            acquisitions.append(host)
    write_lines(out, acquisitions)

    subfinder = tool_path("subfinder", ctx.config)
    if subfinder and acquisitions:
        acq_dir = ensure_dir(passive_dir / "acquisitions")
        for domain in acquisitions[:10]:
            acq_out = acq_dir / f"subfinder_{domain.replace('.', '_')}.txt"
            run_cmd([subfinder, "-d", domain, "-all", "-silent", "-o", str(acq_out)], timeout=300)
    return out


def _resolve_permutations(ctx: ReconContext, raw_path: Path) -> tuple[Path, Path]:
    resolved = ctx.phase1 / "subdomains_resolved.txt"
    wildcards = ctx.phase1 / "wildcards.txt"
    alterx = tool_path("alterx", ctx.config)
    puredns = tool_path("puredns", ctx.config)

    permutations = ctx.phase1 / "permutations.txt"
    if alterx and raw_path.exists() and raw_path.stat().st_size > 0:
        run_cmd([alterx, "-enrich", "-i", str(raw_path), "-o", str(permutations)])
    else:
        if not alterx:
            LOG.warning("alterx not found — skipping permutation expansion")
        permutations = raw_path

    if puredns and permutations.exists() and ctx.config.resolvers.exists():
        run_cmd(
            [
                puredns,
                "resolve",
                str(permutations),
                "-r",
                str(ctx.config.resolvers),
                "--wildcard-tests",
                "5",
                "-o",
                str(resolved),
                "-w",
                str(wildcards),
            ],
            timeout=1800,
        )
    else:
        LOG.warning("puredns or resolvers missing — skipping DNS resolution")
    return resolved, wildcards


def _enrich_dns_records(ctx: ReconContext, subdomains_path: Path) -> None:
    dnsx = tool_path("dnsx", ctx.config)
    if not dnsx or not subdomains_path.exists():
        return

    dns_json = ctx.phase1 / "dns_records.jsonl"
    run_cmd(
        [
            dnsx,
            "-l",
            str(subdomains_path),
            "-a",
            "-cname",
            "-mx",
            "-txt",
            "-resp",
            "-silent",
            "-json",
            "-o",
            str(dns_json),
        ],
        timeout=600,
    )

    cname_lines: list[str] = []
    takeover_lines: list[str] = []
    for record in read_jsonl(dns_json):
        host = record.get("host", "")
        for cname in record.get("cname") or []:
            cname_lines.append(f"{host} → {cname}")
            if any(sig in cname.lower() for sig in TAKEOVER_CNAME_SIGS):
                takeover_lines.append(f"{host} → {cname}")

    write_lines(ctx.phase1 / "cname_records.txt", cname_lines)
    write_lines(ctx.phase1 / "takeover_candidates.txt", takeover_lines)
    if takeover_lines:
        LOG.info("CNAME takeover candidates: %d", len(takeover_lines))


def _reverse_dns_ptr(ctx: ReconContext, ips_path: Path) -> Path:
    """PTR lookups on resolved IPs — surfaces hostnames passive sources miss."""
    out = ctx.phase1 / "reverse_dns_subs.txt"
    dnsx = tool_path("dnsx", ctx.config)
    if not dnsx or not ips_path.exists() or ips_path.stat().st_size == 0:
        return out

    ptr_raw = ctx.phase1 / "ptr_raw.txt"
    run_cmd(
        [dnsx, "-l", str(ips_path), "-ptr", "-resp-only", "-silent", "-o", str(ptr_raw)],
        timeout=300,
    )
    suffix = f".{ctx.target.lower()}"
    roots = ctx.config.scope_roots or ctx.config.targets
    hosts = filter_target_subdomains(read_lines(ptr_raw), roots)
    write_lines(out, hosts)
    if hosts:
        LOG.info("PTR reverse DNS: %d in-scope hostnames", len(hosts))
    return out


def _extract_ips(ctx: ReconContext, subdomains_path: Path) -> Path:
    ips_path = ctx.phase1 / "ips.txt"
    dnsx = tool_path("dnsx", ctx.config)
    if dnsx and subdomains_path.exists():
        run_cmd(
            [dnsx, "-l", str(subdomains_path), "-a", "-resp-only", "-silent", "-o", str(ips_path)],
            timeout=600,
        )
    return ips_path


def _lookup_asns(ctx: ReconContext, ips_path: Path) -> Path:
    asns_path = ctx.phase1 / "asns.txt"
    lines: list[str] = []
    for ip in read_lines(ips_path)[:100]:
        ctx.rate_limiter.wait()
        try:
            resp = requests.get(f"https://ipinfo.io/{ip}/org", timeout=10)
            if resp.ok:
                lines.append(f"{ip} | {resp.text.strip()}")
        except requests.RequestException:
            continue
    write_lines(asns_path, lines)
    return asns_path


def _merge_passive_sources(ctx: ReconContext, passive_dir: Path) -> list[str]:
    merged: list[str] = []
    for path in sorted(passive_dir.glob("*.txt")):
        if path.name in ("github_search_hints.txt",):
            continue
        merged.extend(read_lines(path))
    for path in (passive_dir / "acquisitions").glob("*.txt") if (passive_dir / "acquisitions").exists() else []:
        merged.extend(read_lines(path))

    merged = filter_target_subdomains(merged, ctx.config.scope_roots or ctx.config.targets)
    kept, rejected = filter_in_scope(merged, ctx.config)
    if rejected:
        LOG.warning("Scope gate rejected %d subdomains (fail-closed)", len(rejected))
        write_lines(ctx.phase1 / "scope_rejected.txt", rejected)
    return kept


def run(ctx: ReconContext) -> None:
    phase_banner("Asset Discovery", 1)
    passive_dir = ensure_dir(ctx.phase1 / "passive")

    run_parallel(
        [
            ("subfinder", lambda: _passive_subfinder(ctx, passive_dir)),
            ("amass", lambda: _passive_amass(ctx, passive_dir)),
            ("assetfinder", lambda: _passive_assetfinder(ctx, passive_dir)),
            ("assetfinder_related", lambda: _passive_assetfinder(ctx, passive_dir, related=True)),
            ("subdominator", lambda: _passive_subdominator(ctx, passive_dir)),
            ("bbot", lambda: _passive_bbot(ctx, passive_dir)),
            ("crtsh", lambda: _passive_crtsh(ctx, passive_dir)),
            ("hackertarget", lambda: _passive_hackertarget(ctx, passive_dir)),
            ("otx", lambda: _passive_otx(ctx, passive_dir)),
            ("github", lambda: _github_subdomain_mining(ctx, passive_dir)),
        ],
        max_workers=6,
    )

    _collect_acquisition_domains(ctx, passive_dir)
    merged = _merge_passive_sources(ctx, passive_dir)

    raw_path = ctx.phase1 / "subdomains_raw.txt"
    write_lines(raw_path, merged)

    if not merged:
        LOG.warning("No subdomains found passively — seeding with apex domain")
        write_lines(raw_path, [ctx.target, f"www.{ctx.target}"])

    resolved_path, _ = _resolve_permutations(ctx, raw_path)
    subdomains_path = ctx.phase1 / "subdomains.txt"
    write_lines(subdomains_path, kept_final := list(dict.fromkeys(
        read_lines(raw_path) + read_lines(resolved_path)
    )))
    kept_final, rejected_final = filter_in_scope(kept_final, ctx.config)
    if rejected_final:
        LOG.warning("Scope gate rejected %d resolved subdomains", len(rejected_final))
        write_lines(
            ctx.phase1 / "scope_rejected.txt",
            read_lines(ctx.phase1 / "scope_rejected.txt") + rejected_final,
        )
    write_lines(subdomains_path, kept_final)

    ips_path = _extract_ips(ctx, subdomains_path)
    ptr_hosts = read_lines(_reverse_dns_ptr(ctx, ips_path))
    if ptr_hosts:
        merged_ptr = list(dict.fromkeys(read_lines(subdomains_path) + ptr_hosts))
        kept_ptr, rej_ptr = filter_in_scope(merged_ptr, ctx.config)
        if rej_ptr:
            write_lines(
                ctx.phase1 / "scope_rejected.txt",
                read_lines(ctx.phase1 / "scope_rejected.txt") + rej_ptr,
            )
        write_lines(subdomains_path, kept_ptr)

    _enrich_dns_records(ctx, subdomains_path)
    _lookup_asns(ctx, ips_path)

    LOG.info("Phase 1 complete: %d subdomains", len(read_lines(subdomains_path)))
