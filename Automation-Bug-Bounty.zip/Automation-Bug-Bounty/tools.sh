#!/usr/bin/env bash
# Convenience wrapper — canonical installer lives in scripts/install-tools.sh
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "${ROOT}/scripts/install-tools.sh" "$@"
