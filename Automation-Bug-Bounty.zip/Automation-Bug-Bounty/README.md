# Autonomous Recon Automation

Multi-phase security reconnaissance orchestrator. Runs external recon tools sequentially and produces `DUMP.md` — structured output for vulnerability testing and PoC authoring.

## Quick Start

```bash
# Create virtualenv and install Python deps
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Install recon tools (ProjectDiscovery suite + puredns, ffuf, etc.)
./tools.sh
# or: ./scripts/install-tools.sh

# Configure target
cp recon.config.yaml my-target.yaml
# Edit: set target: "example.com"

# Run
python -m recon --config my-target.yaml
```

## Output

Results land in `recon-{target}-{date}/`:

- `DUMP.md` — paste this to Claude for PoC generation
- `dump.jsonl` — machine-readable summary
- `phase1_assets/` through `phase7_auth/` — per-phase artifacts

## Phases

| Phase | What it does |
|-------|----------------|
| 1 | Passive subdomain enum (10+ sources), permutations, PTR, CNAME/takeover hints, cloud buckets |
| 2 | Port scan (expanded DB/admin ports), httpx, **uncover** origin IPs, **vhost ffuf** on origins, CSP mining, priority targets |
| 3 | URL harvest (gau, waymore, waybackurls, katana, gospider, hakrawler), **sensitive URL filter**, **broken external domains** |
| 4 | JS analysis, source maps, secrets (jsluice, trufflehog, nuclei) |
| 5 | Parameter classification (gf), arjun, paramspider, wayback params |
| 6 | Nuclei scan, subzy + **nuclei takeover** on subs, actuator, header/path bypass, **open redirect probe** (active), **wpscan** (if WP) |
| 7 | API surface, GraphQL, Swagger, CORS, **sensitive path probe**, **ffuf dir fuzz** on priority hosts |

## Config

See `recon.config.yaml` for all options. Key fields:

- `target` — single domain
- `scope_file` — one domain per line
- `auth_cookies` — enables authenticated katana crawl
- `shodan_api_key` — favicon hash → Shodan host search
- `GITHUB_TOKEN` — env var for GitHub code search (subdomain leaks)
- `webhook_url` — Slack/webhook notification on completion
- `resume: true` — skip phases in `.recon_state.json` (use `--no-resume` to restart)
- `mode: active` + `allow_intrusive: true` — enables open redirect probes, header/path bypass, cache poison
- `phases.*` — toggle individual phases
- `out_of_scope_regex` — auto-exclude third-party hosts

## CLI

```bash
python -m recon --config recon.config.yaml
python -m recon -t example.com -v   # override target, verbose
```

## Requirements

External tools are invoked when present on `PATH` or in `tools_path`. Missing tools are skipped with a warning — phases degrade gracefully.

Install via `./tools.sh` (or `./scripts/install-tools.sh`) — also available from repo root as `../tools.sh`.
