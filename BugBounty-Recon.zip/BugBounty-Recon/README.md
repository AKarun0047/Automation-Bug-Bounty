# BugBounty-Recon

**One script** — full recon for manual bug bounty testing. Flat output files, rate-limited, 24/7 ready.

## Install

```bash
chmod +x install.sh recon-all.sh
./install.sh
cp .env.example .env   # optional: SHODAN_API_KEY
```

## Run

```bash
export PATH="${PATH}:$(go env GOPATH)/bin:${HOME}/.pdtm/go/bin:${HOME}/.local/bin"
set -a && source .env && set +a

./recon-all.sh justeattakeaway.com
./recon-all.sh -f targets.txt
./recon-all.sh --daemon -f targets.txt    # 24/7 every 6h

tmux new -s recon   # survive SSH disconnect
```

## Output — `output/<domain>/`

| File | For manual testing |
|------|---------------------|
| `subdomains.txt` | Full sub list |
| `subdomains_new.txt` | **New since last run** |
| `live_hosts.txt` | Live URLs |
| `priority_hosts.txt` | admin/staging/dashboard |
| `httpx_full.txt` | Status, title, tech |
| `urls.txt` | All harvested URLs |
| `sensitive_urls.txt` | High-value URLs → Burp |
| `wayback_params.txt` | Historical param URLs |
| `params_ssrf.txt` | SSRF candidates |
| `params_sqli.txt` | SQLi candidates |
| `params_redirect.txt` | Open redirect |
| `params_idor.txt` | IDOR params |
| `params_xss.txt` | XSS candidates |
| `arjun_results.txt` | Hidden params found |
| `dir_fuzz_results.txt` | ffuf directory hits (recursive, raft-large + CeWL) |
| `recursive_fuzz_results.txt` | **2nd-pass deep fuzz** inside discovered paths |
| `api_fuzz_results.txt` | ffuf API endpoint hits (recursive under `/api/`) |
| `custom_wordlist.txt` | CeWL target-specific words |
| `lfi_fuzz_results.txt` | LFI probe hits (Jhaddix payloads) |
| `vhost_fuzz_results.txt` | ffuf vhost / CDN bypass |
| `sensitive_paths.txt` | /.env, /admin, actuator… |
| `open_ports.txt` | naabu |
| `nmap_results.txt` | Service scan |
| `takeover_candidates.txt` | Subdomain takeover |
| `nuclei_results.txt` | All nuclei findings |
| `nuclei_critical.txt` | Critical + high only |
| `secrets.txt` | Tokens in JS |
| `REPORT_<domain>.txt` | **Start here** |

## Tools used

| Phase | Tools |
|-------|-------|
| Subdomains | subfinder, assetfinder, amass, crt.sh, hackertarget, **ffuf DNS brute (110k)** |
| Live + ports | naabu, httpx, nmap |
| URLs | gauplus, waybackurls, waymore, gospider, hakrawler, katana, uro |
| Params | paramspider, gf, arjun, wayback CDX |
| Fuzzing | ffuf (recursive dirs + API + vhost), CeWL, LFI Jhaddix |
| Vulns | nuclei (broad + fuzz templates), subzy |
| Secrets | nuclei on JS files |

## Wordlists ([CoffSec top 10](https://medium.com/@coffsec/10-recon-wordlists-every-pentester-must-know-484499d2ce9c))

| Article # | Wordlist | File | Used for |
|-----------|----------|------|----------|
| 1 | SecLists | multiple | Base collection |
| 2 | raft-large-directories | `dirs-raft-large.txt` | Directory ffuf (priority hosts) |
| 4 | subdomains-top1million-110000 | `subdomains-top110k.txt` | Subdomain brute (capped) |
| 6 | api-endpoints | `api-endpoints.txt` | `/api/FUZZ` discovery |
| 7 | LFI-Jhaddix | `lfi-jhaddix.txt` | LFI param probing |
| 9 | OneListForAll (short) | `dirs-onelist.txt` | Fallback dir list |
| 10 | CeWL | generated | `custom_wordlist.txt` from live site |

Skipped (password cracking, not recon): rockyou, CrackStation. Optional deep enum: n0kovo (~3M subs) — run manually overnight.

## Rate limits

```bash
export RATE_LIMIT=80
export THREADS=30
export SLEEP_BETWEEN_TOOLS=3
export MAX_FFUF_HOSTS=5
export MAX_ARJUN_HOSTS=15
export MAX_SUBDOMAIN_BRUTE=3000   # cap from 110k sub list

# Recursive fuzzing (on by default)
export RECURSIVE_FUZZ=1
export FFUF_RECURSION_DEPTH=2      # /admin → /admin/users → …
export FFUF_RECURSION_STRATEGY=greedy
export MAX_RECURSIVE_SEEDS=15      # 2nd pass inside discovered paths

# Disable: ./recon-all.sh --no-recursive target.com
```

## Manual testing order

1. `REPORT_<domain>.txt`
2. `subdomains_new.txt` + `takeover_candidates.txt`
3. `nuclei_critical.txt`
4. `params_ssrf.txt` + `params_redirect.txt`
5. `sensitive_urls.txt` → Burp
6. `dir_fuzz_results.txt` + `recursive_fuzz_results.txt` + `sensitive_paths.txt`
7. `priority_hosts.txt` → auth/API
