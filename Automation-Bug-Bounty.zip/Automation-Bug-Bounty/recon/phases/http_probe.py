"""Phase 2 — HTTP Probe + Fingerprint."""

from __future__ import annotations

import ipaddress
import json
import logging
import re
from pathlib import Path

import requests

from recon.config import is_in_scope
from recon.context import ReconContext
from recon.utils import (
    is_interesting_url,
    phase_banner,
    read_jsonl,
    read_lines,
    run_cmd,
    tool_path,
    wordlist_path,
    write_lines,
)

LOG = logging.getLogger("recon.phase2")

WAF_PATTERN = re.compile(r"(?i)(cloudflare|akamai|incapsula|sucuri|aws|imperva|f5)")
PRIORITY_TITLE = re.compile(
    r"(?i)admin|dashboard|console|internal|staging|jenkins|grafana|kibana|login|panel"
)
CSP_HOST = re.compile(r"[a-zA-Z0-9._-]+\.[a-zA-Z0-9.-]+")


def _port_scan(ctx: ReconContext, subdomains_path: Path) -> Path:
    ports_path = ctx.phase2 / "ports.jsonl"
    naabu = tool_path("naabu", ctx.config)
    if not naabu or not subdomains_path.exists():
        LOG.warning("naabu not found or no subdomains — skipping port scan")
        return ports_path

    ports = "21,22,23,25,80,110,143,443,445,3306,5432,6379,8080,8443,3000,3001,4000,4443,5000,8000,8008,8888,9000,9090,9200,9443,27017"
    run_cmd(
        [naabu, "-l", str(subdomains_path), "-p", ports, "-silent", "-json", "-o", str(ports_path)],
        timeout=1800,
    )
    return ports_path


def _build_urls_to_probe(ctx: ReconContext, subdomains_path: Path, ports_path: Path) -> Path:
    urls_path = ctx.phase2 / "urls_to_probe.txt"
    urls: list[str] = []

    for record in read_jsonl(ports_path):
        host = record.get("host") or record.get("ip") or ""
        port = record.get("port")
        if host and port:
            scheme = "https" if int(port) == 443 else "http"
            if int(port) in (80, 443):
                urls.append(f"{scheme}://{host}")
            else:
                urls.append(f"http://{host}:{port}")

    httpx = tool_path("httpx", ctx.config)
    probe_out = ctx.phase2 / "httpx_probe.txt"
    if httpx and subdomains_path.exists():
        run_cmd(
            [httpx, "-l", str(subdomains_path), "-probe", "-silent", "-o", str(probe_out)],
            timeout=1200,
        )
        _ansi = re.compile(r"\x1b\[[0-9;]*m")
        for line in read_lines(probe_out):
            clean = _ansi.sub("", line).strip()
            if "SUCCESS" in clean and clean.startswith("http"):
                urls.append(clean.split()[0])

    if not urls:
        for sub in read_lines(subdomains_path):
            urls.append(f"https://{sub}")
            urls.append(f"http://{sub}")

    write_lines(urls_path, urls)
    return urls_path


def _fingerprint(ctx: ReconContext, urls_path: Path) -> Path:
    assets_path = ctx.phase2 / "assets.jsonl"
    httpx = tool_path("httpx", ctx.config)
    if not httpx or not urls_path.exists():
        return assets_path

    run_cmd(
        [
            httpx,
            "-l",
            str(urls_path),
            "-title",
            "-status-code",
            "-tech-detect",
            "-ip",
            "-cdn",
            "-location",
            "-server",
            "-favicon",
            "-hash",
            "sha256",
            "-ports",
            "80,443,8080,8443,3000,8000",
            "-follow-redirects",
            "-max-redirects",
            "5",
            "-rstr",
            "2097152",
            "-json",
            "-o",
            str(assets_path),
        ],
        timeout=3600,
    )
    _enrich_assets(assets_path)
    return assets_path


def _enrich_assets(assets_path: Path) -> None:
    if not assets_path.exists():
        return

    enriched: list[str] = []
    for record in read_jsonl(assets_path):
        url = record.get("url", "")
        status = record.get("status_code") or record.get("status-code") or 0
        server = str(record.get("webserver") or record.get("server") or "")
        cdn = bool(record.get("cdn", False))

        interesting = is_interesting_url(url)
        if status == 403:
            interesting = True
        if server and re.search(r"/\d", server):
            interesting = True

        record["direct_ip"] = not cdn
        record["interesting"] = interesting
        record["notes"] = record.get("notes", "")
        enriched.append(json.dumps(record))

    assets_path.write_text("\n".join(enriched) + ("\n" if enriched else ""), encoding="utf-8")


def _screenshots(ctx: ReconContext, urls_path: Path) -> None:
    if not ctx.config.phases.screenshots:
        return
    gowitness = tool_path("gowitness", ctx.config)
    if not gowitness or not urls_path.exists():
        LOG.warning("gowitness not found — skipping screenshots")
        return
    run_cmd(
        [
            gowitness,
            "file",
            "-f",
            str(urls_path),
            "-P",
            str(ctx.phase2 / "screenshots"),
            "--timeout",
            "10",
        ],
        timeout=3600,
    )


def _waf_detection(ctx: ReconContext, subdomains_path: Path) -> Path:
    waf_path = ctx.phase2 / "waf_detection.txt"
    wafw00f = tool_path("wafw00f", ctx.config)
    lines: list[str] = []

    hosts = read_lines(subdomains_path)[:50]  # cap for speed
    if wafw00f:
        for host in hosts:
            result = run_cmd([wafw00f, f"https://{host}"], timeout=60)
            if result.stdout:
                lines.append(result.stdout.strip())
    else:
        LOG.warning("wafw00f not found — using httpx CDN hints only")
        for record in read_jsonl(ctx.phase2 / "assets.jsonl"):
            url = record.get("url", "")
            cdn_name = record.get("cdn_name") or record.get("cdn-name") or ""
            if cdn_name:
                lines.append(f"{url}: {cdn_name}")

    waf_path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    return waf_path


def _shodan_favicon_lookup(ctx: ReconContext, assets_path: Path) -> Path:
    out = ctx.phase2 / "shodan_favicon.jsonl"
    if not ctx.config.shodan_api_key or not assets_path.exists():
        if not ctx.config.shodan_api_key:
            LOG.debug("No shodan_api_key — skipping favicon → Shodan lookup")
        return out

    import requests

    hashes: set[str] = set()
    hash_to_url: dict[str, str] = {}
    for record in read_jsonl(assets_path):
        url = record.get("url", "")
        fav_hash = (
            record.get("favicon_hash")
            or record.get("favicon-hash")
            or record.get("favicon_mmh3")
            or record.get("favicon-mmh3")
        )
        if fav_hash is not None and str(fav_hash).strip():
            h = str(fav_hash).strip()
            hashes.add(h)
            hash_to_url.setdefault(h, url)

    records: list[dict] = []
    for h in sorted(hashes)[:20]:
        ctx.rate_limiter.wait()
        try:
            resp = requests.get(
                "https://api.shodan.io/shodan/host/search",
                params={"key": ctx.config.shodan_api_key, "query": f"http.favicon.hash:{h}"},
                timeout=30,
            )
            if resp.ok:
                data = resp.json()
                records.append(
                    {
                        "favicon_hash": h,
                        "source_url": hash_to_url.get(h),
                        "shodan_total": data.get("total", 0),
                        "shodan_hosts": list(
                            dict.fromkeys(
                                host
                                for m in (data.get("matches") or [])
                                for host in (m.get("hostnames") or [])
                                if host
                            )
                        ),
                        "matches": [
                            {"ip": m.get("ip_str"), "hostnames": m.get("hostnames"), "org": m.get("org")}
                            for m in (data.get("matches") or [])[:10]
                        ],
                    }
                )
        except requests.RequestException as exc:
            LOG.debug("Shodan lookup failed for hash %s: %s", h, exc)

    out.write_text(
        "\n".join(json.dumps(r) for r in records) + ("\n" if records else ""),
        encoding="utf-8",
    )
    if records:
        LOG.info("Shodan favicon lookup: %d hashes queried", len(records))
    return out


def _csp_subdomain_mining(ctx: ReconContext, assets_path: Path, subdomains_path: Path) -> Path:
    """Extract subdomains leaked in Content-Security-Policy headers."""
    out = ctx.phase2 / "csp_subdomains.txt"
    roots = ctx.config.scope_roots or [ctx.target]
    suffixes = tuple({r.lower() for r in roots} | {ctx.target.lower()})

    urls: list[str] = [f"https://{ctx.target}", f"http://{ctx.target}"]
    for record in read_jsonl(assets_path):
        if record.get("url"):
            urls.append(record["url"])
    urls = list(dict.fromkeys(urls))[:80]

    found: set[str] = set()
    for url in urls:
        ctx.rate_limiter.wait()
        try:
            resp = requests.head(url, timeout=12, allow_redirects=True)
            csp = resp.headers.get("Content-Security-Policy", "")
            if not csp:
                resp = requests.get(url, timeout=12, allow_redirects=True, stream=True)
                csp = resp.headers.get("Content-Security-Policy", "")
                resp.close()
            for host in CSP_HOST.findall(csp):
                host = host.lower().strip(".")
                if any(host == s or host.endswith(f".{s}") for s in suffixes):
                    found.add(host)
        except requests.RequestException:
            continue

    write_lines(out, sorted(found))
    if not found:
        return out

    existing = set(read_lines(subdomains_path))
    added = [h for h in found if h not in existing and is_in_scope(h, ctx.config)]
    if added:
        write_lines(subdomains_path, sorted(existing | set(added)))
        LOG.info("CSP mining added %d subdomains", len(added))
    return out


def _uncover_origin_hosts(ctx: ReconContext, subdomains_path: Path) -> Path:
    """Find origin hosts/IPs via uncover (Shodan/Censys/FOFA) — CDN bypass intel."""
    out = ctx.phase2 / "uncover_hosts.txt"
    json_out = ctx.phase2 / "uncover_hosts.jsonl"
    uncover = tool_path("uncover", ctx.config)
    if not uncover:
        LOG.warning("uncover not found — skipping CDN/origin discovery (install via pdtm)")
        return out

    queries = [
        f'ssl:"{ctx.target}"',
        f'hostname:"{ctx.target}"',
        ctx.target,
    ]
    hosts: set[str] = set()
    records: list[dict] = []

    for query in queries:
        result = run_cmd(
            [uncover, "-q", query, "-silent"],
            timeout=300,
        )
        for line in result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            hosts.add(line)
            records.append({"query": query, "host": line})

    for sub in read_lines(subdomains_path)[:15]:
        if sub.endswith(f".{ctx.target}") or sub == ctx.target:
            result = run_cmd(
                [uncover, "-q", f'hostname:"{sub}"', "-silent"],
                timeout=120,
            )
            for line in result.stdout.splitlines():
                line = line.strip()
                if line:
                    hosts.add(line)
                    records.append({"query": f'hostname:"{sub}"', "host": line})

    write_lines(out, sorted(hosts))
    if records:
        json_out.write_text(
            "\n".join(json.dumps(r) for r in records) + "\n",
            encoding="utf-8",
        )
        LOG.info("Uncover: %d origin host/IP candidates", len(hosts))
    return out


def _is_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host.split(":")[0])
        return True
    except ValueError:
        return False


def _ffuf_vhost_fuzz(
    ctx: ReconContext,
    uncover_path: Path,
    assets_path: Path,
    subdomains_path: Path,
) -> Path:
    """Tanvir 2026 — vhost fuzz on origin IPs (CDN bypass)."""
    out = ctx.phase2 / "vhost_fuzz_hits.txt"
    ffuf = tool_path("ffuf", ctx.config)
    wordlist = wordlist_path(ctx.config, "vhost-subdomains-top100k.txt")
    if not ffuf or not wordlist:
        LOG.warning("ffuf or vhost wordlist missing — skipping vhost fuzz")
        return out

    ips: set[str] = set()
    for line in read_lines(uncover_path):
        if _is_ip(line):
            ips.add(line.split(":")[0])

    for record in read_jsonl(assets_path):
        if record.get("cdn"):
            continue
        url = record.get("url", "")
        host = url.split("//")[-1].split("/")[0].split(":")[0]
        if _is_ip(host):
            ips.add(host)

    if not ips:
        return out

    hits: list[str] = []
    subs_sample = read_lines(subdomains_path)[:5] or [ctx.target]
    for ip in sorted(ips)[:3]:
        for seed in subs_sample:
            suffix = seed if seed.endswith(ctx.target) else f".{ctx.target}"
            fuzz_out = ctx.phase2 / f"vhost_ffuf_{ip.replace('.', '_')}.json"
            run_cmd(
                [
                    ffuf,
                    "-w",
                    str(wordlist),
                    "-u",
                    f"https://{ip}/",
                    "-H",
                    f"Host: FUZZ{suffix}",
                    "-mc",
                    "200,301,302,403",
                    "-t",
                    str(min(ctx.config.threads, 40)),
                    "-timeout",
                    "10",
                    "-of",
                    "json",
                    "-o",
                    str(fuzz_out),
                    "-s",
                ],
                timeout=600,
            )
            if fuzz_out.exists():
                try:
                    data = json.loads(fuzz_out.read_text(encoding="utf-8"))
                    for result in data.get("results", []):
                        host = result.get("input", {}).get("FUZZ", "")
                        hits.append(f"{ip} → Host: {host}{suffix} [{result.get('status')}]")
                except (json.JSONDecodeError, OSError):
                    continue

    write_lines(out, hits)
    if hits:
        LOG.info("Vhost fuzz: %d hits on origin IPs", len(hits))
    return out


def _priority_targets(ctx: ReconContext, assets_path: Path) -> Path:
    out = ctx.phase2 / "priority_targets.txt"
    lines: list[str] = []
    for record in read_jsonl(assets_path):
        url = record.get("url", "")
        title = str(record.get("title") or "")
        status = record.get("status_code") or record.get("status-code") or ""
        if title and PRIORITY_TITLE.search(title):
            lines.append(f"{url} [{status}] {title}")
        elif record.get("interesting"):
            lines.append(f"{url} [{status}] interesting")
    write_lines(out, lines)
    return out


def run(ctx: ReconContext) -> None:
    phase_banner("HTTP Probe + Fingerprint", 2)
    subdomains_path = ctx.phase1 / "subdomains.txt"

    ports_path = _port_scan(ctx, subdomains_path)
    urls_path = _build_urls_to_probe(ctx, subdomains_path, ports_path)
    _fingerprint(ctx, urls_path)
    assets_path = ctx.phase2 / "assets.jsonl"
    _shodan_favicon_lookup(ctx, assets_path)
    uncover_path = _uncover_origin_hosts(ctx, subdomains_path)
    _csp_subdomain_mining(ctx, assets_path, subdomains_path)
    _ffuf_vhost_fuzz(ctx, uncover_path, assets_path, subdomains_path)
    _priority_targets(ctx, assets_path)
    _screenshots(ctx, urls_path)
    _waf_detection(ctx, subdomains_path)

    assets = read_jsonl(ctx.phase2 / "assets.jsonl")
    LOG.info("Phase 2 complete: %d live assets", len(assets))
